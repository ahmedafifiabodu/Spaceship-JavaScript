//Creating a Phaser Game Scene
let gameScene = new Phaser.Scene("Game")

let userInput;
let player;
let background;

let hearts;
let maxHearts = 4;
let currentHearts = maxHearts;
let additionalPhotos
let activeHearts = [];

let gameOver = false;
let gameOverText;
let restartButton;
let overlay;

// Store enemy bodies
let enemyBodies = [];
let enemyGroup;
let speedEnemy = -2.0;

let score = 0;
let scoreText;

// Track whether the game is in the start state
let inStartState = true;

let shootCounter = 0; // Counter to keep track of the number of shots
const shootLimit = 5; // Set the maximum number of shots before cooldown
const cooldownTime = 2000; // Set the cooldown time in milliseconds (adjust as needed)
const maxFireRate = 100; // Maximum fire rate for the progress bar
let currentFireRate = maxFireRate; // Current fire rate for the progress bar
let lastShootTime = 0; // Track the time of the last shot
const fireRate = 200; // Set the fire rate in milliseconds (adjust as needed)
let fireRateBar;
//const fireRateAnimations = ['increaseFireRate4', 'increaseFireRate3', 'increaseFireRate2', 'increaseFireRate1', 'increaseFireRate0'];
const fireRateAnimations = ['increaseFireRate0', 'increaseFireRate1', 'increaseFireRate2', 'increaseFireRate3', 'increaseFireRate4'];

let autoUpdateTimer;
let manualUpdate = false;

let cooldownText;

// Variable to keep track of time elapsed
let elapsedTime = 0;

// Collision categories
const collisionCategories = {
    player: 0x0001,
    asteroid: 0x0002,
    bullet: 0x0004,
    heart: 0x0008
};

gameScene.preload = function () {

    //Background Parallax
    this.load.image("parallax1", "Assets/Pixel Space/Environment Pack/Backgrounds/PNGs/Condesed/Starry background  - Layer 01 - Void.png");
    this.load.image("parallax2", "Assets/Pixel Space/Environment Pack/Backgrounds/PNGs/Condesed/Starry background  - Layer 02 - Stars.png");
    this.load.image("parallax3", "Assets/Pixel Space/Environment Pack/Backgrounds/PNGs/Condesed/Starry background  - Layer 03 - Stars.png");

    //health hearts
    this.load.image("backgroundHeart", "Assets/Hearts/background.png");
    this.load.image("heart", "Assets/Hearts/heart.png");

    //Main Player
    this.load.spritesheet("player", "Assets/Pixel Space/Main Ship/Main Ship/Main Ship/Main Ship - Bases/PNGs/allforms.png", {
        frameWidth: 48, frameHeight: 48,
        startFrame: 0, endFrame: 3
    });

    //weapons{missle battery}
    this.load.spritesheet("missles", "Assets/Pixel Space/Main Ship/Main Ship/Main Ship/Main Ship - Weapons/PNGs/Main Ship - Weapons - Auto Cannon.png",
        {
            frameWidth: 48, frameHeight: 48,
            startFrame: 0, endFrame: 6

        });

    //Main Player Shooting
    this.load.spritesheet("playerRocketShooting", "Assets/Pixel Space/Main Ship/Main Ship/Main ship weapons/PNGs/Main ship weapon - Projectile - Auto cannon bullet.png",
        {
            frameWidth: 32, frameHeight: 32,
            startFrame: 0, endFrame: 3
        });

    //Shooting Bar
    this.load.spritesheet("fireRateBar", "Assets/Pixel UI/Fire Rate.png",
        {
            frameWidth: 48, frameHeight: 24,
        });

    //Enemies
    //Asteroid 01
    this.load.image("asteroid", "Assets/Pixel Space/Environment Pack/Asteroids/PNGs/Asteroid 01 - Base.png");

    // this.load.spritesheet("asteroid", "Assets/Pixel Space/Environment Pack/Asteroids/PNGs/Asteroid 01 - Base.png",
    // {
    //     frameWidth: 96, frameHeight: 80,
    // });

    //Asteroid 02
    this.load.spritesheet("asteroid2", "Assets/Pixel Space/Environment Pack/Asteroids/PNGs/Asteroid 01 - Explode.png",
        {
            frameWidth: 100, frameHeight: 96,
            startFrame: 1, endFrame: 6
        });

    // Load audio files
    this.load.audio('shootSound', 'Assets/Music/comedy_missle_launch.mp3');
    this.load.audio('collisionSound', 'Assets/Music/damage.mp3');
    this.load.audio('collisionSoundAsteroid2', 'Assets/Music/asteroid2.mp3');
    this.load.audio('Heal', 'Assets/Music/Heal Sound Effect2.mp3');
    this.load.audio('cooldown', 'Assets/Music/Cooldown.wav');
    this.load.audio('gameover', 'Assets/Music/Gameover.mp3');

    // Load background sound
    this.load.audio('backgroundSound', 'Assets/Music/spaceship.mp3');
};

gameScene.create = function () {

    if (inStartState) {

        // Create the parallax backgrounds here
        const scaleY = this.scale.height / this.textures.get('parallax1').getSourceImage().height

        this.parallax1 = this.add.tileSprite(0, 0, this.scale.width, this.scale.height, 'parallax1').setOrigin(0, 0).setScale(scaleY);
        this.parallax2 = this.add.tileSprite(0, 0, this.scale.width, this.scale.height, 'parallax2').setOrigin(0, 0).setScale(scaleY);
        this.parallax3 = this.add.tileSprite(0, 0, this.scale.width, this.scale.height, 'parallax3').setOrigin(0, 0).setScale(scaleY);

        //Player
        player = this.matter.add.sprite(0, 500, "player")
            .setBounce(0.0)
            .setScale(1.2)
            .setScrollFactor(0)
            .setFrictionAir(0.05)
            .setMass(-30)
            .setInteractive();
        ;

        player.setCircle(25, {
            radius: 150,
            isSensor: true, // Set the sensing region as a sensor (no physical interaction, only collision events)
            collisionFilter: {
                category: collisionCategories.asteroid, // Set collision category for the sensing region
                // mask: collisionCategories.player // Set collision mask for the sensing region (collide with the player)
            }
        })
            .setAngle(90)
            .setFixedRotation();

        // Set collision category for the player
        player.setCollisionCategory(collisionCategories.player);

        // Set collision mask for the player (collide with asteroids and hearts)
        player.setCollidesWith([collisionCategories.asteroid, collisionCategories.heart]);

        // Player Animation
        player.anims.create({
            key: 'full_health',
            frames: [{ key: 'player', frame: 0 }],
            frameRate: 1
        });
        player.anims.create({
            key: 'semi_damaged',
            frames: [{ key: 'player', frame: 1 }],
            frameRate: 1
        });
        player.anims.create({
            key: 'damaged',
            frames: [{ key: 'player', frame: 2 }],
            frameRate: 1
        });
        player.anims.create({
            key: 'heavyly_damaged',
            frames: [{ key: 'player', frame: 3 }],
            frameRate: 1
        });

        player.anims.play('full_health', true);

        missle = this.add.sprite(0, 0, "missles")
            .setScale(1.2)
            .setScrollFactor(0)
            .setAngle(90)

        // Create a fire rate bar sprite
        fireRateBar = this.add.sprite(player.x, player.y - 30, 'fireRateBar');
        fireRateBar.setOrigin(0.5, 1); // Set origin to the bottom center
        fireRateBar.setScale(currentFireRate / maxFireRate, 1);

        for (let i = 0; i < fireRateAnimations.length; i++) {
            this.anims.create({
                key: fireRateAnimations[i],
                frames: this.anims.generateFrameNumbers('fireRateBar', { start: 4 - i, end: 4 }),
                frameRate: 10,
                repeat: 0,
                hideOnComplete: true
            });
        }

        // Missle Animation
        missle.anims.create({
            key: 'firing',
            frames: this.anims.generateFrameNumbers('missles', { frames: [0, 1, 2, 3, 4, 5, 6] }),
            frameRate: 10
        });
        missle.anims.create({
            key: 'idle',
            frames: this.anims.generateFrameNumbers('missles', { frames: 0 }),
            frameRate: 0
        });

        missle.anims.play('idle', true);

        // Heart
        additionalPhotos = [];
        hearts = [];
        for (let i = 0; i < maxHearts; i++) {
            let heart = this.add.image(50 + i * 20, 50, "heart").setScrollFactor(0);
            hearts.push(heart);

            // Create an additional photo for each heart
            let additionalPhoto = this.add.image(50 + i * 20, 50, 'backgroundHeart').setScrollFactor(0);
            additionalPhoto.setVisible(false);
            additionalPhotos.push(additionalPhoto);
        }

        // Spawn hearts every 10000 milliseconds
        this.time.addEvent({
            delay: 10000,
            callback: generateRandomHearts,
            callbackScope: this,
            loop: true
        });

        // Create the score text at the top right corner
        scoreText = this.add.text(config.width - 10, 10, 'Score: 0', { fontSize: '16px', fill: '#fff' });
        scoreText.setOrigin(1, -1);

        // Create audio instances
        shootSound = this.sound.add('shootSound');
        collisionSound = this.sound.add('collisionSound');
        collisionSoundAsteroid2 = this.sound.add('collisionSoundAsteroid2');
        heal_sound = this.sound.add("Heal");

        cooldownSound = this.sound.add('cooldown');
        gameoverSound = this.sound.add('gameover');

        cooldownText = this.add.text(player.x, player.y - 50, '', { font: '16px Arial', fill: '#ffffff' });
        cooldownText.setOrigin(0.5, 1);

        // Create background sound instance
        background = this.sound.add('backgroundSound', { loop: true });
        background.play();
        background.setVolume(1);

        // Create an enemy group
        enemyGroup = this.add.group();

        // Hide the mouse cursor during gameplay
        this.input.setDefaultCursor('none');

        return;
    }

};

gameScene.update = function (time, delta) {

    if (gameOver) {
        return; // Don't update anything if the game is over
    }

    let speed1 = 0.5;
    let speed2 = 1.0;
    let speed3 = 1.5;

    // Update elapsed time
    elapsedTime += delta;

    // Check if 5 minutes have passed
    if (elapsedTime >= 50000) {
        // Speed up the parallax backgrounds
        speed1 += 0.5;
        speed2 += 1.0;
        speed3 += 1.5;

        speedEnemy -= 2.0;
        // Reset elapsed time
        elapsedTime = 0;
    }

    this.parallax1.tilePositionX += speed1
    this.parallax2.tilePositionX += speed2
    this.parallax3.tilePositionX += speed3

    const pointer = this.input.activePointer;

    player.x = pointer.x;
    player.y = pointer.y;

    missle.x = pointer.x;
    missle.y = pointer.y;

    fireRateBar.x = pointer.x;
    fireRateBar.y = pointer.y - 30;

    cooldownText.x = pointer.x;
    cooldownText.y = pointer.y - 60;

    // Generate enemies at the right edge of the screen
    if (Phaser.Math.Between(1, 100) <= 2) {
        generateAsteroid01(this);
    }

    // Generate the new enemy at the right edge of the screen
    if (Phaser.Math.Between(1, 1000) <= 2) {
        generateAsteroid02(this);
    }

    // Check if enough time has passed since the last shot for automatic update
    if (!gameOver && (this.time.now - lastShootTime) > 2000) {
        shootCounter = 0;
        currentFireRate = maxFireRate;

        // Calculate the frame index for the automatic update
        const frameIndex = shootCounter;
        fireRateBar.setFrame(frameIndex);

        updateFireRateBar();
    }

    this.input.on('pointerdown', function (pointer) {
        if (!gameOver && pointer.leftButtonDown() && (this.time.now - lastShootTime) > fireRate) {
            if ((this.time.now - lastShootTime) > 2000) {
                shootCounter = 0;
                currentFireRate = maxFireRate;
            }

            if (shootCounter < shootLimit) {
                missle.anims.play('firing', true);
                shootBullet(player.x, player.y, this);
                lastShootTime = this.time.now;
                currentFireRate += 10;

                // Calculate the frame index based on shootCounter
                const frameIndex = shootCounter;
                fireRateBar.setFrame(frameIndex);

                shootCounter++;

                if (shootCounter === shootLimit) {
                    // Play the sound when the player shoots 5 times and has to wait 3 seconds
                    cooldownSound.play();

                    // Display the cooldown text
                    cooldownText.setText('Cooldown 2 seconds');
                    this.time.delayedCall(2000, function () {
                        cooldownText.setText(''); // Hide the cooldown text after 3 seconds
                    });
                }

                if (currentFireRate > maxFireRate) {
                    currentFireRate = maxFireRate;
                }
            } else if (shootCounter >= shootLimit && (this.time.now - lastShootTime) > cooldownTime) {
                shootCounter = 0;
                currentFireRate -= 5;
                if (currentFireRate < 0) {
                    currentFireRate = 0;
                }
            }
        }
        updateFireRateBar();
    }, this);

    // Check for collisions between player and asteroid1
    this.matter.world.on('collisionstart', function (event) {
        event.pairs.forEach(pair => {
            const bodyA = pair.bodyA;
            const bodyB = pair.bodyB;

            // Check if one of the bodies is the player and the other is an asteroid
            if (
                (bodyA.gameObject && bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'player' &&
                    bodyB.gameObject && bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'asteroid') ||
                (bodyB.gameObject && bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'player' &&
                    bodyA.gameObject && bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'asteroid')
            ) {
                // Get the circle bounds of the sensing region

                // Play collision sound
                collisionSound.play();

                // Reduce player's health
                currentHearts--;

                // Update the hearts UI
                updateHearts();

                // Check if the player is out of hearts (game over condition)
                if (currentHearts <= 0) {
                    console.log("Game Over");
                    gameOvers.call(this); // Call the gameOver function
                }

                // Destroy the asteroid
                if (bodyA.gameObject && bodyA.gameObject.texture.key === 'asteroid') bodyA.gameObject.destroy();
                if (bodyB.gameObject && bodyB.gameObject.texture.key === 'asteroid') bodyB.gameObject.destroy();

                // Update player's texture
                updatePlayerTexture();
            }
        });
    });

    // Check for collisions between player and asteroid2
    this.matter.world.on('collisionstart', function (event) {
        event.pairs.forEach(pair => {
            const bodyA = pair.bodyA;
            const bodyB = pair.bodyB;

            // Check if one of the bodies is the player and the other is the sensing region of asteroid2
            if (
                (bodyA.gameObject && bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'player' &&
                    bodyB.gameObject && bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'asteroid2') ||
                (bodyB.gameObject && bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'player' &&
                    bodyA.gameObject && bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'asteroid2')
            ) {
                // Handle collision events with the sensing region of asteroid2
                // Play the animation frames 2, 3, 4, 5 of asteroid2
                if (
                    bodyB.gameObject &&
                    bodyB.gameObject.anims &&
                    bodyB.gameObject.anims.exists('asteroid2Animation') &&
                    bodyB.gameObject.texture
                ) {
                    const asteroid2Animation = bodyB.gameObject.anims.get('asteroid2Animation');

                    // Play collision sound
                    collisionSoundAsteroid2.play();

                    // Check if the animation is not already playing
                    if (!asteroid2Animation.isPlaying) {

                        // Get the circle bounds of the sensing region
                        const circleBounds = new Phaser.Geom.Circle(
                            bodyB.gameObject.x,  // Use the x position of asteroid2
                            bodyB.gameObject.y,  // Use the y position of asteroid2
                            125  // Use the radius of the circle, It is bigger than the actual range
                        );

                        // Listen for the complete event on the Game Object (not the animation)
                        const completeEvent = 'animationcomplete-asteroid2Animation';
                        const completeCallback = function () {

                            // Animation completed, check if the player is still overlapping
                            const isPlayerOverlapping = Phaser.Geom.Intersects.CircleToRectangle(
                                circleBounds,
                                bodyA.gameObject.getBounds()
                            );

                            if (isPlayerOverlapping) {

                                // Player is still overlapping with asteroid2 after the animation, reduce player's health
                                currentHearts--;

                                // Update the hearts UI
                                updateHearts();

                                // Update player's texture
                                updatePlayerTexture();
                            }

                            // Destroy the asteroid
                            if (bodyB.gameObject && bodyB.gameObject.texture.key === 'asteroid2') bodyB.gameObject.destroy();

                            // Remove the event listener to ensure it only triggers once
                            bodyB.gameObject.off(completeEvent, completeCallback); //There is an error but it made the function works x-)
                        };

                        // Listen for the complete event on the Game Object (not the animation)
                        bodyB.gameObject.once(completeEvent, completeCallback);

                        // Play frames 2, 3, 4, 5 of the animation
                        bodyB.gameObject.anims.play('asteroid2Animation', true);

                    }
                }

                // Check if the player is out of hearts (game over condition)
                if (currentHearts <= 0) {
                    console.log("Game Over");
                    gameOvers.call(this); // Call the gameOver function
                }
            }
        });
    });

    // Check for collisions between bullets and Enemys
    this.matter.world.on('collisionstart', function (event) {
        event.pairs.forEach(pair => {
            const bodyA = pair.bodyA;
            const bodyB = pair.bodyB;

            // Check if both bodies have a gameObject property
            if (bodyA.gameObject && bodyB.gameObject) {
                // Check if one of the bodies is a bullet and the other is an asteroid
                const isBulletA = bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'playerRocketShooting';
                const isBulletB = bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'playerRocketShooting';
                const isAsteroidA = bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'asteroid';
                const isAsteroidB = bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'asteroid';
                const isAsteroid2A = bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'asteroid2';
                const isAsteroid2B = bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'asteroid2';

                if (((isBulletA && isAsteroidB) || (isBulletB && isAsteroidA)) || ((isBulletA && isAsteroid2B) || (isBulletB && isAsteroid2A))) {

                    // Check if bodyA is a bullet and increment the score
                    if (isBulletA) {
                        bodyA.gameObject.destroy();
                        score += 1;
                        updateScoreText();
                    }

                    // Check if bodyB is a bullet and increment the score
                    if (isBulletB) {
                        bodyB.gameObject.destroy();
                        score += 1;
                        updateScoreText();
                    }

                    // Destroy both bodies if they still exist
                    if (bodyA.gameObject) bodyA.gameObject.destroy();
                    if (bodyB.gameObject) bodyB.gameObject.destroy();
                }

            }
        });
    });

    // Check if any enemy has gone out of bounds from the left side
    const worldBounds = this.matter.world.bounds;

    // Ensure enemyGroup is defined before accessing bodies
    if (enemyGroup && enemyGroup.bodies) {
        enemyGroup.bodies.forEach(body => {
            if (body.gameObject && body.gameObject.texture && body.gameObject.texture.key === 'asteroid') {
                if (body.bounds.right < worldBounds.left) {
                    // Destroy the enemy if it has gone out of bounds
                    body.gameObject.destroy();
                }
            }

            if (body.gameObject && body.gameObject.texture && body.gameObject.texture.key === 'asteroid2') {
                if (body.bounds.right < worldBounds.left) {
                    // Destroy the enemy if it has gone out of bounds
                    body.gameObject.destroy();
                }
            }
        });
    }

    // Check for collisions between player and hearts
    this.matter.world.on('collisionstart', function (event) {
        event.pairs.forEach(pair => {
            const bodyA = pair.bodyA;
            const bodyB = pair.bodyB;

            // Check if one of the bodies is the player and the other is a heart
            if (
                (bodyA.gameObject && bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'player' &&
                    bodyB.gameObject && bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'heart') ||
                (bodyB.gameObject && bodyB.gameObject.texture && bodyB.gameObject.texture.key === 'player' &&
                    bodyA.gameObject && bodyA.gameObject.texture && bodyA.gameObject.texture.key === 'heart')
            ) {
                // Find the heart object in the activeHearts array
                const activeHeart = activeHearts.find(item => item.heart.body === bodyA || item.heart.body === bodyB);

                heal_sound.setVolume(50);
                heal_sound.play();

                // Check if the heart is still active
                if (activeHeart) {

                    // Stop and destroy the tween
                    activeHeart.tween.stop();
                    activeHeart.tween.destroy();

                    // Destroy the heart
                    activeHeart.heart.destroy();

                    // Remove the heart from the activeHearts array
                    activeHearts = activeHearts.filter(item => item !== activeHeart);

                    // Increase player's hearts
                    currentHearts++;
                    if (currentHearts > maxHearts) {
                        currentHearts = maxHearts;
                    }

                    // Update the hearts UI
                    updateHearts();

                    // Update player's texture
                    updatePlayerTexture();
                }
            }
        });
    });
};

function updateFireRateBar() {
    const scale = currentFireRate / maxFireRate;
    fireRateBar.setScale(scale, 1);
}

function updateScoreText() {
    if (scoreText) {
        scoreText.setText('Score: ' + score);
    }
}

function updateHearts() {
    for (let i = 0; i < maxHearts; i++) {
        hearts[i].setVisible(i < currentHearts);
        additionalPhotos[i].setVisible(i >= currentHearts);
    }
}

function updatePlayerTexture() {
    if (currentHearts === 4) {
        player.anims.play('full_health', true);
    } else if (currentHearts === 3) {
        player.anims.play('semi_damaged', true);
    } else if (currentHearts === 2) {
        player.anims.play('damaged', true);
    } else if (currentHearts === 1) {
        player.anims.play('heavyly_damaged', true);
    }
}

function shootBullet(x, y, scene) {

    // Check if the game is over
    if (gameOver) {
        return;
    }

    // Play shoot sound
    shootSound.play();

    //console.log("Shooting bullet at (" + x + ", " + y + ")");

    // Create a bullet sprite at the player's position
    const bullet = scene.matter.add.sprite(x, y, "playerRocketShooting")
        .setAngle(90)
        .setCollisionCategory(collisionCategories.bullet) // Set collision category for the bullet
        .setCollidesWith([collisionCategories.asteroid]); // Set collision mask for the bullet (collide with asteroids)

    // Add a custom property to identify it as a player bullet
    bullet.isPlayerBullet = true;

    if (!scene.anims.exists('playerRocketShootingAnimation')) {
        scene.anims.create({
            key: "playerRocketShootingAnimation",
            frames: scene.anims.generateFrameNumbers(
                "playerRocketShooting",
                {
                    start: 0, end: 3
                }),
            frameRate: 10,
            repeat: -1
        })
    }

    // Play the bullet animation
    bullet.anims.play('playerRocketShootingAnimation', true);

    bullet.setVelocityX(7);

    // Automatically destroy the bullet when it goes out of bounds
    bullet.outOfBoundsKill = true;

    // Destroy the bullet after a certain time or when it goes off-screen
    scene.time.delayedCall(5000, function () {
        bullet.destroy();
    });
}

function generateRandomHearts() {

    // Check if the game is in the "game over" state
    if (gameOver) {
        return;
    }

    const heart = this.matter.add.image(this.sys.game.config.width, Phaser.Math.Between(100, this.sys.game.config.height - 100), "heart");
    heart.setScrollFactor(0);
    heart.setSensor(true)
        .setCollisionCategory(collisionCategories.heart) // Set collision category for the Hearts
        .setCollidesWith([collisionCategories.player]); // Set collision mask for the Hearts (collide with player)

    // Set up a tween to move the heart from the right to the left
    const tween = this.tweens.add({
        targets: heart,
        x: 0,
        duration: 3000,
        onComplete: function () {

            // Destroy the heart after the tween completes
            heart.destroy();
        }
    });

    // Add the heart to the activeHearts array
    activeHearts.push({ heart, tween });
}

// function generateAsteroid01(scene) {

//     const enemy = scene.matter.add.sprite(
//         scene.sys.game.config.width,
//         Phaser.Math.Between(100, scene.sys.game.config.height - 100),
//         "asteroid"
//     );

//     // Set the enemy's velocity
//     enemy.setVelocityX(-2).setFrictionAir(0).setMass(1)
//         .setCollisionCategory(collisionCategories.asteroid) // Set collision category for the bullet
//         .setCollidesWith([collisionCategories.bullet, collisionCategories.asteroid, collisionCategories.player]); // Set collision mask for the bullet (collide with asteroids)

//     // Adjust the physics body size (you may need to experiment with the radius value)
//     const physicsRadius = 25; // Adjust this value as needed
//     enemy.setCircle(physicsRadius);

//     // Automatically destroy the enemy when it goes out of bounds
//     enemy.outOfBoundsKill = true;

//     // Add the enemy to the enemy group
//     enemy.setInteractive();
//     enemyGroup.add(enemy);

//     // Store the enemy body in the array
//     enemyBodies.push(enemy.body);

//     // Destroy the bullet after a certain time or when it goes off-screen
//     scene.time.delayedCall(20000, function () {
//         enemy.destroy();
//     });
// }

function generateAsteroid01(scene) {

    // Create the new enemy sprite
    const asteroid = scene.matter.add.sprite(
        scene.sys.game.config.width,
        Phaser.Math.Between(200, scene.sys.game.config.height - 200),
        "asteroid"
    );

    // Play the new enemy animation
    // newEnemy.anims.play('newEnemyAnimation', true);

    // Create a sensing region around the asteroid2
    asteroid.setCircle(20, {
        radius: 150,
        isSensor: true, // Set the sensing region as a sensor (no physical interaction, only collision events)
        collisionFilter: {
            category: collisionCategories.asteroid, // Set collision category for the sensing region
            mask: collisionCategories.player // Set collision mask for the sensing region (collide with the player)
        }
    });

    // Set the new enemy's velocity and other properties
    asteroid.setVelocityX(speedEnemy).setFrictionAir(0).setMass(1)
        .setCollisionCategory(collisionCategories.asteroid) // Set collision category for the bullet
        .setCollidesWith([collisionCategories.bullet, collisionCategories.asteroid, collisionCategories.player]); // Set collision mask for the bullet (collide with asteroids)

    // Automatically destroy the new enemy when it goes out of bounds
    // scene.time.delayedCall(20000, function () {
    //     asteroid2.destroy();
    // });

    // Add the new enemy to the enemy group
    asteroid.setInteractive();
    enemyGroup.add(asteroid);

    // Store the enemy body in the array
    enemyBodies.push(asteroid.body);
}

function generateAsteroid02(scene) {

    // Create the new enemy sprite
    const asteroid2 = scene.matter.add.sprite(
        scene.sys.game.config.width,
        Phaser.Math.Between(200, scene.sys.game.config.height - 200),
        "asteroid2"
    );

    // Set up new enemy animation
    asteroid2.anims.create({
        key: "asteroid2Animation",
        frames: asteroid2.anims.generateFrameNumbers(
            "asteroid2",
            {
                start: 2, end: 4
            }),
        frameRate: 5,
        repeat: 0
    });

    // Play the new enemy animation
    // newEnemy.anims.play('newEnemyAnimation', true);

    // Create a sensing region around the asteroid2
    asteroid2.setCircle(45, {
        radius: 150,
        isSensor: true, // Set the sensing region as a sensor (no physical interaction, only collision events)
        collisionFilter: {
            category: collisionCategories.asteroid, // Set collision category for the sensing region
            mask: collisionCategories.player // Set collision mask for the sensing region (collide with the player)
        }
    });

    // Set the new enemy's velocity and other properties
    asteroid2.setVelocityX(speedEnemy).setFrictionAir(0).setMass(1)
        .setCollisionCategory(collisionCategories.asteroid) // Set collision category for the bullet
        .setCollidesWith([collisionCategories.bullet, collisionCategories.asteroid, collisionCategories.player]); // Set collision mask for the bullet (collide with asteroids)

    // Automatically destroy the new enemy when it goes out of bounds
    // scene.time.delayedCall(20000, function () {
    //     asteroid2.destroy();
    // });

    // Add the new enemy to the enemy group
    asteroid2.setInteractive();
    enemyGroup.add(asteroid2);

    // Store the enemy body in the array
    enemyBodies.push(asteroid2.body);
}

function gameOvers() {

    gameOver = true;

    gameoverSound.play();

    gameScene.input.setDefaultCursor('auto');

    // Clear the activeHearts array
    activeHearts.forEach(item => {
        item.heart.destroy();
        item.tween.stop();
        item.tween.destroy();
    });
    activeHearts = [];

    // Reset the visibility of additional photos
    additionalPhotos.forEach(photo => photo.setVisible(false));

    // Hide the player and hearts
    player.setVisible(false);
    missle.setVisible(false);
    fireRateBar.setVisible(false);
    hearts.forEach(heart => heart.setVisible(false));

    // Create a dark overlay
    overlay = this.scene.add.rectangle(0, 0, game.config.width, game.config.height, 0x000000, 0.7);
    overlay.setOrigin(0, 0);

    // Display game over text
    gameOverText = this.scene.add.text(400, 300, 'Game Over', { fontSize: '32px', fill: '#fff' });
    gameOverText.setOrigin(0.5);

    // Display restart button
    restartButton = this.scene.add.text(400, 400, 'Restart', { fontSize: '24px', fill: '#fff' });
    restartButton.setOrigin(0.5);
    restartButton.setInteractive();

    // Set up the pointer over and pointer out events for the hover effect
    restartButton.on('pointerover', function () {
        restartButton.setStyle({ fill: '#ff0' }); // Change fill color on hover
    });

    restartButton.on('pointerout', function () {
        restartButton.setStyle({ fill: '#fff' }); // Reset fill color on pointer out
    });

    restartButton.on('pointerdown', restartGame, this);

    // Destroy all stored enemy bodies
    enemyBodies.forEach(body => {
        if (body.gameObject) {
            body.gameObject.destroy();
        }
    });

    // Clear the array
    enemyBodies = [];

    // Reset the score
    score = 0;
    updateScoreText();

    // Pause the background music
    background.pause();
}

// Modify your existing 'restartGame' function
function restartGame() {

    // Reset the game state when restarting
    inStartState = false;

    gameScene.input.setDefaultCursor('none');

    // Reset game over state
    gameOver = false;

    // Clear the activeHearts array
    activeHearts.forEach(item => {
        item.heart.destroy();
        item.tween.stop();
        item.tween.destroy();
    });
    activeHearts = [];

    // Remove game over text and restart button
    if (gameOverText) {
        gameOverText.destroy();
        overlay.destroy();
    }
    if (restartButton) {
        restartButton.destroy();
    }

    // Show the player and hearts
    player.setVisible(true);
    missle.setVisible(true);
    fireRateBar.setVisible(true);
    hearts.forEach(heart => heart.setVisible(true));

    // Reset player's health
    currentHearts = maxHearts;
    updateHearts();
    updatePlayerTexture();

    // Stop the background music
    background.stop();

    // Resume the background music
    background.play();
}

////////////////////////////////////// START SCREEN //////////////////////////////////////
let startScene = new Phaser.Scene("Start");

startScene.preload = function () {

    // Load Earth
    this.load.spritesheet('Earth', 'Assets/Pixel Space/Environment Pack/Planets/PNGs/Earth-Like planet.png', {
        frameWidth: 96, frameHeight: 96,
        startFrame: 0, endFrame: 76
    });

    this.load.audio('start', 'Assets/Music/Start.mp3');
};

startScene.create = function () {

    // Create the Earth sprite
    additionalBackground = this.add.sprite(config.width / 2 - 145, config.height / 2 - 200, 'Earth').setOrigin(0, 0).setScale(3);
    additionalBackground.anims.create({
        key: "Earth_Animatoin",
        frames: additionalBackground.anims.generateFrameNumbers(
            "Earth",
            {
                start: 0, end: 76
            }),
        frameRate: 15,
        repeat: -1
    })

    // Play the bullet animation
    additionalBackground.anims.play('Earth_Animatoin', true);

    // Add Welcome Text text
    welcomeText = this.add.text(config.width / 2, config.height / 2 - 250, 'Welcome to Spaceship!\n\nClick "Start Game" to begin.', { fontSize: '24px', fill: '#fff', align: 'center' });
    welcomeText.setOrigin(0.5);

    // Add tutorial text
    welcomeText = this.add.text(config.width / 2, config.height / 2 + 250,
        'Tutorials\n\n1)Left Click to shoot.\n2)Move the cursor to move the player.', { fontSize: '18px', fill: '#fff', align: 'center' });
    welcomeText.setOrigin(0.5);

    // Add any other elements to the start screen (e.g., buttons, title text, etc.)
    const startButton = this.add.text(400, 500, 'Start Game', { fontSize: '32px', fill: '#fff' }).setOrigin(0.5);
    startButton.setInteractive();

    // Set up the pointer over and pointer out events for the hover effect
    startButton.on('pointerover', function () {
        startButton.setStyle({ fill: '#ff0' }); // Change fill color on hover
    });

    startButton.on('pointerout', function () {
        startButton.setStyle({ fill: '#fff' }); // Reset fill color on pointer out
    });

    startButton.on('pointerdown', function () {
        // Start the main game scene when the button is clicked
        this.scene.start("Game");
    }, this);

    startSound = this.sound.add('start', { loop: false });
    startSound.play();

    startSound.on('complete', function () {
        // Set up a delayed callback to start the sound again after 2 seconds
        this.time.delayedCall(400, function () {
            startSound.play();
        }, [], this);
    }, this);
};
////////////////////////////////////// START SCREEN //////////////////////////////////////

let config = {

    type: Phaser.AUTO,

    width: 800,
    height: 800,
    scene: [startScene, gameScene],

    physics: {
        default: 'matter',
        matter: {
            gravity: { x: 0, y: 0 },
            debug: false
        }
    },

    fps: {
        target: 60,
        forceSetTimeOut: true // Force the use of setTimeout for better accuracy
    },
    render: {
        antialias: true, // Enable antialiasing
        pixelArt: false, // Disable pixelArt mode
        roundPixels: false // Disable rounding of pixel positions
    }
}

let game = new Phaser.Game(config)